// U3E2 · Uso del objeto window
// Completa las funciones sin cambiar sus nombres.
// Todas las páginas utilizan este archivo. Cada página tiene su propio contexto.

// Referencia compartida por las funciones de ventanas de ESTA página.
let ventanaAuxiliar = null;

// 1. Dirección y navegador

function mostrarDireccion() {
    console.log(location.href);
    console.log(location.hostname);
    console.log(location.pathname);
    console.log(location.search);
}

function mostrarNavegador() {
    console.log(navigator.language);
    console.log(navigator.languages);
    console.log(navigator.onLine);
    console.log(navigator.userAgent);
}

// 2. Dimensiones y desplazamiento

function mostrarDimensiones() {
    console.log(window.innerWidth);
    console.log(window.innerHeight);
    console.log(window.outerWidth);
    console.log(window.outerHeight);
    console.log(window.screenX);
    console.log(window.screenY);
    console.log(window.screen.width);
    console.log(window.screen.height);
    console.log(window.screen.availWidth);
    console.log(window.screen.availHeight);
}

function bajar() {
    window.scrollBy(0, 300);
}

function subir() {
    window.scrollBy(0, -300);
}

function irAPosicion() {
    window.scrollTo(0, 1000);
}

function volverAlInicio() {
    window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth"
    });
}

// 3. Navegación e historial

function irAlLaboratorio() {
    window.location.assign("laboratorio.html");
}

function irAlResultado() {
    window.location.assign("resultado.html");
}

function sustituirPorResultado() {
    window.location.replace("resultado.html");
}

function recargarPagina() {
    if (window.confirm("¿Quieres recargar la página?")) {
        window.location.reload();
    }
}

function retroceder() {
    window.history.back();
}

function avanzar() {
    window.history.forward();
}

function consultarHistorial() {
    console.log(window.history.length);
}

// 4. Ventanas

function abrirAuxiliar() {
    if (window.confirm("¿Quieres abrir una ventana auxiliar?")) {
        ventanaAuxiliar = window.open(
            "resultado.html",
            "auxiliar",
            "popup,width=400,height=250,left=500,top=300"
        );

        if (ventanaAuxiliar === null) {
            window.alert("No se ha podido abrir la ventana auxiliar.");
        }
    }
}

function reutilizarAuxiliar() {
    ventanaAuxiliar = window.open("inicio.html", "auxiliar");
}

function abrirOtraPestana() {
    window.open("resultado.html", "_blank");
}

function abrirPaginaExterna() {
    window.open("https://www.mozilla.org/", "_blank");
}

function cerrarAuxiliar() {
    if (ventanaAuxiliar !== null && !ventanaAuxiliar.closed) {
        ventanaAuxiliar.close();
    } else {
        window.alert("No hay ninguna ventana auxiliar abierta.");
    }
}

// 5. Escritura del documento

function abrirEscrituraCarga() {
    window.open("escritura_carga.html", "ventanaCarga");
}

function abrirEscrituraPosterior() {
    window.open("escritura_posterior.html", "ventanaPosterior");
}

function escribirDuranteCarga() {
    document.write("<h2>Escritura durante la carga</h2>");
    document.write("<p>Este párrafo se ha generado utilizando JavaScript.</p>");
}

function sobrescribirDocumento() {
    if (window.confirm("¿Quieres sobrescribir el documento?")) {
        document.write("<h1>Documento sobrescrito</h1>");
        document.write("<p>El contenido anterior ha sido reemplazado.</p>");
    }
}

// Llamada automática: no la cambies ni la elimines.
// El script se carga al final del cuerpo, sin defer, mientras se analiza el HTML.
if (document.body.id === "pagina-escritura-carga") {
    escribirDuranteCarga();
}
