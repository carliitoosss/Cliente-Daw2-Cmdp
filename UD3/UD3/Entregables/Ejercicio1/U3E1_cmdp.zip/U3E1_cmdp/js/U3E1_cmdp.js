let nombreProyecto=prompt("Introduce el nombre de tu proyecto:");
let diaMes=prompt("Introduce el dia del mes que se realizara revisiones anual del proyecto.");
let mes=prompt("Introduce el mes en que se realizara revisiones anual del proyecto.");

let nombreMiniscula=nombreProyecto.toLowerCase();
let nombreMayuscula=nombreProyecto.toUpperCase();
let separado=nombreMiniscula.split(" ");
let primeraPalabra=separado[0];
let primeraLetra=primeraPalabra.substring(0,1);
let segundaPalabra=separado[1];
let segundaLetra=segundaPalabra.substring(0,1);
let ultimaPalabra=separado[2];
let terceraLetra=ultimaPalabra.substring(0,1);
let nombreSinEspacios=nombreProyecto.replaceAll(" ","");
let numLetras=nombreSinEspacios.length;
let codigoProyecto=primeraLetra+segundaPalabra+terceraLetra;

console.log("DATOS DEL PROYECTO");
console.log(" ");
console.log("Primera palabra: "+primeraPalabra);
console.log("Segunda palabra: "+segundaPalabra);
console.log("Tercera palabra: "+ultimaPalabra);
console.log(" ");
console.log("Nombre completo: "+nombreProyecto);
console.log("Número de letras: "+numLetras);
console.log(" ");
console.log("Código de Proyecto: " + codigoProyecto);

let fechaDespegue=new Date(2027,5,15,12,0,0);
let diaHoy=new Date();
let diferencia=fechaDespegue-diaHoy;
diferencia=diferencia/(1000 *60 *60 *24);
diasRestante=parseInt(diferencia);
console.log(" ")
console.log("Quedan "+diasRestante+" días para el lanzamiento de la misión");
let añoActual=diaHoy.getFullYear();

let diaRevision=diaMes;
let mesRevision=mes-1;
let aniosLunes=[];
console.log(" ");
console.log("La revisión anual del proyecto caerá en lunes en los años:");

for(i=añoActual; i<=2050;i++){
    let fecha=new Date(i,mesRevision,diaRevision);
    if(fecha.getDay()=== 1){
        console.log(i);
        aniosLunes.push(i);    
    }
}
console.log("PROYECTO PREPARADO PARA LA MISIÓN");
/*console.log("La revisión anual del proyecto caerá en lunes en los años:");
console.log(aniosLunes);*/


