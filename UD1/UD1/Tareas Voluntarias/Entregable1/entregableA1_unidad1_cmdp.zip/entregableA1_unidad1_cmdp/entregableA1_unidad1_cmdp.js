let fraseAlert="Me gusta Programar";
let boton=document.getElementById("mostrarAlert");
boton.addEventListener("click",function(){
    alert(fraseAlert);
    console.log(fraseAlert);
});